// Netlify Function — Consultor de Marketing (IA)
// Recebe a conversa do navegador e fala com a API da Anthropic usando a SUA
// chave, que fica guardada na variável de ambiente ANTHROPIC_API_KEY do Netlify.

const BRIEFING = [
  'Total de comentários analisados: 34.710',
  'Distribuição de sentimentos: positivo 61,3%, neutro 9,2%, negativo 29,6%',
  '',
  'Aspectos mais citados em comentários NEGATIVOS:',
  '  - Entrega / Prazo: 59,0%',
  '  - Qualidade do Produto: 56,9%',
  '  - Atendimento: 17,6%',
  '  - Expectativa / Anúncio: 16,4%',
  '  - Preço / Custo: 7,0%',
  '',
  'Aspectos mais citados em comentários POSITIVOS:',
  '  - Entrega / Prazo: 57,1%',
  '  - Qualidade do Produto: 49,8%',
  '  - Expectativa / Anúncio: 11,8%',
  '  - Atendimento: 11,6%',
  '  - Preço / Custo: 5,0%',
  '',
  'Modelo: TF-IDF (uni+bigramas) + Regressão Logística. Acurácia 78,6%, F1-macro 0,663.',
  'Base: Olist Brazilian E-Commerce.'
].join('\n');

function systemPrompt(tom) {
  const estilo = tom === 'Detalhado'
    ? 'Explique o raciocínio com detalhe, sempre ancorado nos números.'
    : 'Seja prático e direto, no máximo 5 recomendações acionáveis.';
  return 'Você é um consultor de marketing orientado a dados conversando com a equipe. '
    + 'Use ESTRITAMENTE os dados reais abaixo, citando os percentuais quando relevante. '
    + 'Priorize os aspectos que mais geram insatisfação. Responda em português. ' + estilo
    + '\n\nDADOS REAIS DA ANÁLISE:\n' + BRIEFING;
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Use POST.' };
  }
  const API_KEY = process.env.ANTHROPIC_API_KEY;
  const MODEL = process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-5';
  if (!API_KEY) {
    return { statusCode: 500, body: 'ANTHROPIC_API_KEY não configurada no Netlify.' };
  }
  try {
    const { messages = [], tom = 'Direto' } = JSON.parse(event.body || '{}');
    const turns = messages
      .filter(m => m && (m.role === 'user' || m.role === 'assistant') && m.content)
      .map(m => ({ role: m.role, content: String(m.content) }));

    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 1024,
        system: systemPrompt(tom),
        messages: turns
      })
    });

    if (!r.ok) {
      const err = await r.text();
      return { statusCode: 502, body: 'Erro da API Anthropic: ' + err.slice(0, 300) };
    }
    const data = await r.json();
    const text = (data.content || []).filter(b => b.type === 'text').map(b => b.text).join('');
    return {
      statusCode: 200,
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ text })
    };
  } catch (e) {
    return { statusCode: 500, body: 'Falha ao consultar a IA: ' + (e && e.message ? e.message : String(e)) };
  }
};
